/**
 * virtmem.c 
 * Written by Michael Ballantyne 
 */

#include <stdio.h>
#include <sys/mman.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <stdlib.h>
#include <string.h>

#define TLB_SIZE 16
#define PAGES 256
#define PAGE_MASK 255

#define PAGE_SIZE 256
#define OFFSET_BITS 8
#define OFFSET_MASK 255

#define MEMORY_SIZE PAGES * PAGE_SIZE

// Max number of characters per line of input file to read.
#define BUFFER_SIZE 10

struct tlbentry {
    unsigned char logical;
    unsigned char physical;
};

// TLB is kept track of as a circular array, with the oldest element being overwritten once the TLB is full.
struct tlbentry tlb[TLB_SIZE];

// number of inserts into TLB that have been completed. Use as tlbindex % TLB_SIZE for the index of the next TLB line to use.
int tlbindex = 0;

// pagetable[logical_page] is the physical page number for logical page. Value is -1 if that logical page isn't yet in the table.
int pagetable[PAGES];

signed char main_memory[MEMORY_SIZE];

// Pointer to memory mapped backing file
signed char *backing;

// -----------------------------------------------------------------
// -------- YOUR CODE HERE: helper functions of your choice --------
// a f unction that searches in the tlb if the logical adress was searched before going to search in the page table
int TLB_Search(int logical_page , struct tlbentry tlb[]){
	int i = 0 ;
	int return_val = PAGE_MASK;
	for (i = 0; i < TLB_SIZE ; i++){
		if(logical_page == ((tlb[i]).logical)){
			return_val = return_val & (tlb[i]).physical;
			return return_val;
		}
	}
	return -1;
}




int Page_Table_Serch(int vir_p ,int pagetable[] ){
	int i;
	for (i = 0 ; i < PAGES ; i++){
		if (pagetable[i] == vir_p)
			return i;
	}
	return -1;
}
// -----------------------------------------------------------------

int main(int argc, const char *argv[])
{
    if (argc != 3) {
        fprintf(stderr, "Usage ./virtmem backingstore input\n");
        exit(1);
    }

    const char *backing_filename = argv[1]; 
    int backing_fd = open(backing_filename, O_RDONLY);
    backing = mmap(0, MEMORY_SIZE, PROT_READ, MAP_PRIVATE, backing_fd, 0); 

    const char *input_filename = argv[2];
    FILE *input_fp = fopen(input_filename, "r");

    // Fill page table entries with -1 for initially empty table.
    int i;
    for (i = 0; i < PAGES; i++) 
    {
        pagetable[i] = -1;
    }

    // Character buffer for reading lines of input file.
    char buffer[BUFFER_SIZE];

    // Data we need to keep track of to compute stats at end.
    int total_addresses = 0;
    int tlb_hits = 0;
    int page_faults = 0;

    // Number of the next unallocated physical page in main memory
    unsigned char free_page = 0;
	
	//////////////////////////////////////////////////////////////////////
	FILE* BS_FILE = fopen("BACKING_STORE.bin","r");
	//fopen(&BS_FILE,"BACKING_STORE.bin","rb");
	//////////////////////////////////////////////////////////////////////

    while (fgets(buffer, BUFFER_SIZE, input_fp) != NULL) 
    {
        int logical_address = atoi(buffer);

        // -------------------------------------------------------------------------------------
        // -------- YOUR CODE HERE: translation of logical address to physical address  --------
		int physical_address;
		signed char value = 0;
		total_addresses++;
		int virtual_p = 0;
		virtual_p = logical_address >> 8;
		//virtual_p = virtual_p >> 8 ; // now virtul_p has the virtual page for the address
		int off_m = PAGE_MASK ; // converting the offset to integer becauses it may not work over a char & int 
		int in_page_address = logical_address & off_m; //OFFSET
		int result_TLBS = -1;
		
		result_TLBS = TLB_Search(virtual_p,tlb);
		int physical_f;
		
		
		if (result_TLBS != -1 ){ //this means that the adress already exists in the TLB
			tlb_hits++;
			physical_f = result_TLBS;
		}
		else {//this means that the wanted page does not exist in the TLB
			physical_f = Page_Table_Serch(virtual_p , pagetable);
			if(physical_f == -1){ //this  means that the page we need is not on the memory
				int j;
				for(j=0 ; j< PAGE_SIZE ; j++){//this is suppused to copy the wanted page from the file to the main memory
					fseek(BS_FILE,(PAGE_SIZE*virtual_p +j),SEEK_SET);
					main_memory[(free_page*PAGE_SIZE) +j] = fgetc(BS_FILE); 
				}
				/*fseek(BS_FILE,(PAGE_SIZE*virtual_p),SEEK_SET);
				fread(&main_memory[free_page*PAGE_SIZE],1,PAGE_SIZE,BS_FILE);*/
				pagetable[free_page] = virtual_p;
				page_faults++;
				physical_f = free_page;
				free_page = (free_page+1)%PAGES;
			}
			tlb[tlbindex].logical = virtual_p;
			tlb[tlbindex].physical = physical_f;
			tlbindex = (tlbindex+1)%TLB_SIZE;
			
			
		}
			value = main_memory[( physical_f * PAGE_SIZE) + in_page_address ];
			physical_address = (physical_f *PAGE_SIZE) + in_page_address;
        // -------------------------------------------------------------------------------------
        printf("Virtual address: %d Physical address: %d Value: %d\n", logical_address, physical_address, value);
    }

    printf("Number of Translated Addresses = %d\n", total_addresses);
    printf("Page Faults = %d\n", page_faults);
    printf("Page Fault Rate = %.3f\n", page_faults / (1. * total_addresses));
    printf("TLB Hits = %d\n", tlb_hits);
    printf("TLB Hit Rate = %.3f\n", tlb_hits / (1. * total_addresses));

    return 0;
}
