#include <linux/ctype.h>
#include <linux/config.h>
#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/slab.h>
#include <linux/fs.h>
#include <linux/errno.h>
#include <linux/types.h>
#include <linux/proc_fs.h>
#include <linux/fcntl.h>
#include <asm/system.h>
#include <asm/uaccess.h>
#include <linux/string.h>

#include "encdec.h"

MODULE_LICENSE("GPL");
MODULE_AUTHOR("MOHANNAD AHMAD");

#define MODULE_NAME "encdec"
#define CAESAR_MINOR 0
#define XOR_MINOR 1

int 	encdec_open(struct inode *inode, struct file *filp);
int 	encdec_release(struct inode *inode, struct file *filp);
int 	encdec_ioctl(struct inode *inode, struct file *filp, unsigned int cmd, unsigned long arg);

ssize_t encdec_read_caesar( struct file *filp, char *buf, size_t count, loff_t *f_pos );
ssize_t encdec_write_caesar(struct file *filp, const char *buf, size_t count, loff_t *f_pos);

ssize_t encdec_read_xor( struct file *filp, char *buf, size_t count, loff_t *f_pos );
ssize_t encdec_write_xor(struct file *filp, const char *buf, size_t count, loff_t *f_pos);

int memory_size = 0;

MODULE_PARM(memory_size, "i");

int major = 0;

char* caesar_buffer; /* global buffer for caesar cipher device */
char* xor_buffer;    /* global buffer for xor cipher device */

struct file_operations fops_caesar = {
	.open 	 =	encdec_open,
	.release =	encdec_release,
	.read 	 =	encdec_read_caesar,
	.write 	 =	encdec_write_caesar,
	.llseek  =	NULL,
	.ioctl 	 =	encdec_ioctl,
	.owner 	 =	THIS_MODULE
};

struct file_operations fops_xor = {
	.open 	 =	encdec_open,
	.release =	encdec_release,
	.read 	 =	encdec_read_xor,
	.write 	 =	encdec_write_xor,
	.llseek  =	NULL,
	.ioctl 	 =	encdec_ioctl,
	.owner 	 =	THIS_MODULE
};

// Implemetation suggestion:
// -------------------------
// Use this structure as your file-object's private data structure
typedef struct {
	unsigned char key;
	int read_state;
} encdec_private_date;

int init_module(void)
{
    // Implemetation suggestion:
	// -------------------------
	// 1. Allocate memory for the two device buffers using kmalloc (each of them should be of size 'memory_size')

	major = register_chrdev(major, MODULE_NAME, &fops_caesar);
	if(major < 0)
	{
		return major;
	}

    /* Allocate the buffers for the 2 ciphers */

    caesar_buffer = kmalloc(memory_size*sizeof(char),GFP_KERNEL);
    xor_buffer = kmalloc(memory_size*sizeof(char),GFP_KERNEL);

	return 0;
}

void cleanup_module(void)
{
	// Implemetation suggestion:
	// -------------------------
	// 1. Unregister the device-driver
	// 2. Free the allocated device buffers using kfree

    unregister_chrdev(major,MODULE_NAME); /*** unregister the device here **/

    /* free ciphers buffers */

    kfree(caesar_buffer);
    kfree(xor_buffer);
}

int encdec_open(struct inode *inode, struct file *filp)
{
	// Implemetation suggestion:
	// -------------------------
	// 1. Set 'filp->f_op' to the correct file-operations structure (use the minor value to determine which)
	// 2. Allocate memory for 'filp->private_data' as needed (using kmalloc)

    int minor = MINOR(inode->i_rdev);

    /* choose a suitable file_operations for the file object according to the input minor */

    if(minor != CAESAR_MINOR && minor != XOR_MINOR)
    {
        return -ENODEV;
    }

    if(minor == CAESAR_MINOR)
    {
      filp->f_op = &fops_caesar;
    }

    if(minor == XOR_MINOR)
    {
      filp->f_op = &fops_xor;
    }

    /* allocate memory for filp->private_data */

    filp->private_data = (encdec_private_date*)kmalloc(sizeof(encdec_private_date), GFP_KERNEL);

    /* assign default values for the key and read_state fields of filp->private_data */

    ((encdec_private_date*)filp->private_data)->key = 0;
    ((encdec_private_date*)filp->private_data)->read_state = ENCDEC_READ_STATE_DECRYPT;

	return 0;
}

int encdec_release(struct inode *inode, struct file *filp)
{
	// Implemetation suggestion:
	// -------------------------
	// 1. Free the allocated memory for 'filp->private_data' (using kfree)

    encdec_private_date* temp_data = (encdec_private_date*)filp->private_data;
	kfree(temp_data);
	filp->private_data = NULL;

	return 0;
}

int encdec_ioctl(struct inode *inode, struct file *filp, unsigned int cmd, unsigned long arg)
{
	// Implemetation suggestion:
	// -------------------------
	// 1. Update the relevant fields in 'filp->private_data' according to the values of 'cmd' and 'arg'

    int minor = MINOR(inode->i_rdev);

	if(cmd == ENCDEC_CMD_CHANGE_KEY)
    {
        ((encdec_private_date*)filp->private_data)->key = arg;
    }

	if(cmd == ENCDEC_CMD_SET_READ_STATE)
    {
        ((encdec_private_date*)filp->private_data)->read_state = arg;
    }

	if(cmd == ENCDEC_CMD_ZERO)
    {
        if(minor == CAESAR_MINOR)
        {
            memset(caesar_buffer,0,memory_size);
        }

        if(minor == XOR_MINOR)
        {
            memset(xor_buffer,0,memory_size);
        }
    }

	return 0;
}

// Add implementations for:
// ------------------------
// 1. ssize_t encdec_read_caesar( struct file *filp, char *buf, size_t count, loff_t *f_pos );
// 2. ssize_t encdec_write_caesar(struct file *filp, const char *buf, size_t count, loff_t *f_pos);
// 3. ssize_t encdec_read_xor( struct file *filp, char *buf, size_t count, loff_t *f_pos );
// 4. ssize_t encdec_write_xor(struct file *filp, const char *buf, size_t count, loff_t *f_pos);

ssize_t encdec_read_caesar( struct file *filp, char *buf, size_t count, loff_t *f_pos )
{
    int i;
    encdec_private_date* temp_data = (encdec_private_date*)filp->private_data;
    size_t temp_count = count;

    if(*f_pos == memory_size) /* check if we are at the end of the buffer */
    {
        return -EINVAL;
    }

    if((*f_pos +  count) > memory_size) /* If a user tries to read more than we have , read only as many chars as we have left */
    {
        temp_count = memory_size - *f_pos;
    }

    if(temp_data->read_state == ENCDEC_READ_STATE_DECRYPT)
    {
          /* decrypt the user's message that exists in the caesar buffer */

          for(i = *f_pos; i < (*f_pos + temp_count); i++)
          {
            caesar_buffer[i] = (caesar_buffer[i] - temp_data->key) % 128;

            if(caesar_buffer[i] < 0)
            {
              caesar_buffer[i] = -caesar_buffer[i];
            }
        }

        copy_to_user(buf, caesar_buffer + *f_pos, temp_count); /* copy the decrypted buffer to the user */

        /* reset the user's message that exists in the caesar buffer to encrypted state */

        for(i = *f_pos; i < (*f_pos + temp_count); i++)
        {
           caesar_buffer[i] = (caesar_buffer[i] + temp_data->key) % 128;
        }
     }

     if(temp_data->read_state == ENCDEC_READ_STATE_RAW)
     {
       copy_to_user(buf, caesar_buffer + *f_pos, temp_count); /* copy the raw encrypted buffer to the user */
     }

    *f_pos = *f_pos + count; /* update current reading position */

    return count;
}

ssize_t encdec_write_caesar(struct file *filp, const char *buf, size_t count, loff_t *f_pos)
{
    int i;
    encdec_private_date* temp_data = (encdec_private_date*)filp->private_data;

    if(*f_pos == memory_size) /* check if we are at the end of the buffer */
    {
        return -ENOSPC;
    }

    if((*f_pos + count) > memory_size) /* If a user tries to write more than we have, then do not write anything */
    {
        return -ENOSPC;
    }

    copy_from_user(caesar_buffer + *f_pos, buf, count); /* copy the user's message to caesar_buffer */

     /* encrypt the user's message that exists in the caesar buffer */

      for(i = *f_pos; i < (*f_pos + count); i++)
      {
        caesar_buffer[i] = (caesar_buffer[i] + temp_data->key) % 128;
      }

    *f_pos = *f_pos + count; /* update current writing position */

    return count;
}

ssize_t encdec_read_xor( struct file *filp, char *buf, size_t count, loff_t *f_pos )
{
    int i;
    encdec_private_date* temp_data = (encdec_private_date*)filp->private_data;
    size_t temp_count = count;

    if(*f_pos == memory_size) /* check if we are at the end of the buffer */
    {
        return -EINVAL;
    }

    if((*f_pos +  count) > memory_size) /* If a user tries to read more than we have, read only as many chars as we have left */
    {
        temp_count = memory_size - *f_pos;
    }

    if(temp_data->read_state == ENCDEC_READ_STATE_DECRYPT)
    {
        /* decrypt the user's message that exists in the xor buffer */

        for(i = *f_pos; i < (*f_pos + temp_count); i++)
        {
           xor_buffer[i] = (xor_buffer[i] ^ temp_data->key);
        }

        copy_to_user(buf, xor_buffer + *f_pos, temp_count); /* copy the decrypted buffer to the user */

        /* reset the user's message that exists in the xor buffer to encrypted state */

        for(i = *f_pos; i < (*f_pos + count); i++)
        {
           xor_buffer[i] = (xor_buffer[i] ^ temp_data->key);
        }
     }

     if(temp_data->read_state == ENCDEC_READ_STATE_RAW)
     {
       copy_to_user(buf, xor_buffer + *f_pos, temp_count); /* copy the raw encrypted buffer to the user */
     }

    *f_pos = *f_pos + count; /* update current reading position */

    return count;
}

ssize_t encdec_write_xor(struct file *filp, const char *buf, size_t count, loff_t *f_pos)
{
    int i;
    encdec_private_date* temp_data = (encdec_private_date*)filp->private_data;

    if(*f_pos == memory_size) /* check if we are at the end of the buffer */
    {
        return -ENOSPC;
    }

    if((*f_pos + count) > memory_size) /* If a user tries to write more than we have, then do not write anything */
    {
        return -ENOSPC;
    }

    copy_from_user(xor_buffer + *f_pos, buf, count); /* copy the user's message to xor_buffer */

     /* encrypt the user's message that exists in the xor buffer */

      for(i = *f_pos; i < (*f_pos + count); i++)
      {
        xor_buffer[i] = (xor_buffer[i] ^ temp_data->key);
      }

    *f_pos = *f_pos + count; /* update current writing position */

    return count;
}
