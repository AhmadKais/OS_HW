#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <limits.h>
#include "concurrent_list.h"

struct node {
  int value;
  node* next_p; 
  pthread_mutex_t node_lock;
  
};

struct list {
    node* list_head; 
};

void print_node(node* node)
{
  // DO NOT DELETE
  if(node)
  {
    printf("%d ", node->value);
  }
}

list* create_list()
{
    list* list_p = (list*)(malloc(sizeof(list)));
    if (list_p == NULL) {
        printf("Allocation failed\n");
        return NULL;
    }
    list_p->list_head = NULL;
    return list_p;
    return NULL; 
}

void delete_list(list* list)
{
    if (list == NULL)//in case there is no list
		return;  
    node* pointer = list ->list_head; //otherwise the list does exist and 
    if (pointer == NULL) 
        return; //the list does exist but its empty it has no elements 
    pthread_mutex_lock(&(pointer ->node_lock)); //locks the head
    node* next1 = pointer->next_p;
    node* bef; //new pointer bef = before
    if (next1 == NULL) //the list have one node then delete it
    {
        pthread_mutex_unlock(&(pointer->node_lock));
        pthread_mutex_destroy(&(pointer->node_lock));
        free(pointer);
        return;
    }
    pthread_mutex_lock(&(next1->node_lock)); //lock the next node that comes after the head
	//there is more that one node in the list we need to delete all nodes 
	//we locj the surrnebt nodes we are deleting right now we do not lock allt he list 
	//so that other threads can get and do what ever t hey want 
    while (1){
     pthread_mutex_unlock(&(pointer->node_lock)); // unlock current node the pointer
     bef = pointer; //bef as in before
     pointer = next1; // pointer now pointes at the next node that comes after ita
     pthread_mutex_destroy(&(bef->node_lock));
     free(bef); // free bef because it is a pointer to current pointer
     next1 = next1->next_p; // pointer now pointes at the next node
     if(next1 == NULL) break; // exit loop if we are at the last node of the list
     pthread_mutex_lock(&(next1->node_lock)); // lock the current node we are at 
    }
    //there is still one element that we did not unlock so we unlock  
    pthread_mutex_unlock(&(pointer->node_lock));
    pthread_mutex_destroy(&(pointer->node_lock));
    free(pointer);
    list->list_head = NULL;
    free(list);
}

//**************************************************************************
void insert_value(list* list, int value){
	if (list == NULL ) //this  means that the list was not even created 
		return ;
	//other wise the list was creater now we need tocreate a new node;
	node* new_node = (node*)malloc(sizeof(*new_node));
	if (new_node == NULL) //this  means that memory allocation has failed and we could not create a new node 
		return;
	//memory allocation was succesfull
	new_node->value = value;
	new_node->next_p = NULL;
	pthread_mutex_init(&new_node->node_lock, NULL);
	pthread_mutex_lock(&(new_node->node_lock)); 
	
	node* iter = list->list_head;
	
	if(iter == NULL){ //this means that the list is empty 
		list->list_head = new_node;
		pthread_mutex_unlock(&(new_node->node_lock));
		return;
	}
	// thie list is not empty we need to look for a proper place to insert the new node to keep the list sorted
	pthread_mutex_lock(&(iter->node_lock));
	
	while(iter->value <= value && iter->next_p != NULL ){
		pthread_mutex_unlock(&(iter->node_lock));
		iter = iter->next_p;
		pthread_mutex_lock(&(iter->node_lock));
	}
	
	if(iter == list->list_head && iter->value > value){//this means that the first node in the list is bigger than the value that we inserted and we need to insert the new node in the first place in the list 
		//pthread_mutex_lock(&iter->node_lock, NULL);
		new_node->next_p = iter;
		list->list_head = new_node;
		pthread_mutex_unlock(&(iter->node_lock));
		pthread_mutex_unlock(&(new_node->node_lock));
		return;
	}
	if(iter->next_p == NULL && iter->value <= value ){// this means that we need to insert the new valuue to the end of the list this includes the case where we have only one node in the list  
		iter->next_p = new_node;
		pthread_mutex_unlock(&(iter->node_lock));
		pthread_mutex_unlock(&(new_node->node_lock));
		return;
	}
	
	//now the last case is where we need to insert the new node between two existing nodes
	node* prev = list->list_head ;
	
	while (prev->next_p != iter){
		prev = prev->next_p;
	}
	//now we need to insert the new value between prev and iter
	pthread_mutex_lock(&(prev->node_lock));
	prev->next_p = new_node;
	new_node->next_p = iter;
	pthread_mutex_unlock(&(prev->node_lock));
	pthread_mutex_unlock(&(iter->node_lock));
	pthread_mutex_unlock(&(new_node->node_lock));
	return;
}
//**************************************************************************
void remove_value(list* list, int value){
	//in case the list is empty or the list was not even created
	if(list == NULL || list->list_head == NULL )
		return ;
	
	node* iter = list->list_head;
	//in case the element that we want to delete is the first element in the list 
	if(iter->value == value){
		//in case there is more than one element in the list
		if(iter->next_p != NULL){	
			node* post = iter->next_p;
			pthread_mutex_lock(&(iter->node_lock));
			pthread_mutex_lock(&(post->node_lock));
			list->list_head = post;
			pthread_mutex_unlock(&(post->node_lock));
			pthread_mutex_unlock(&(iter->node_lock));
			pthread_mutex_destroy(&(iter->node_lock));
			free(iter);
			return;
		}
		else{//the list has only one element
			pthread_mutex_lock(&(iter->node_lock));
			list->list_head = NULL;
			pthread_mutex_unlock(&(iter->node_lock));
			pthread_mutex_destroy(&(iter->node_lock));
			free(iter);
			return;
		}
	}
	while(iter->next_p != NULL && iter->value != value ){
		iter = iter->next_p;
	}
	//in case the element does not exist in the list there is no need for us to remove it 
	if(iter->next_p == NULL && iter->value != value){
		return;
	}
	//we need to remove the last element in the list
	if(iter->value == value && iter->next_p == NULL){
		pthread_mutex_lock(&(iter->node_lock));
	//in case the are is more that one element in the list and we need to delete the last one 
			node* prev = list->list_head;
			while(prev->next_p != iter ){
				prev = prev->next_p;
			}
			pthread_mutex_lock(&(prev->node_lock));
			prev->next_p = NULL;
			pthread_mutex_unlock(&(iter->node_lock));
			pthread_mutex_destroy(&(iter->node_lock));
			free(iter);
			pthread_mutex_unlock(&(prev->node_lock));
			return;
	}
	//the cases left is that we need to delete the element that has prev and next 
	node* prev = list->list_head;
	while(prev->next_p != iter ){
		prev = prev->next_p;
	}
	node* post = iter->next_p;
	pthread_mutex_lock(&(prev->node_lock));
	pthread_mutex_lock(&(post->node_lock));
	prev->next_p = post;
	pthread_mutex_unlock(&(iter->node_lock));
	pthread_mutex_destroy(&(iter->node_lock));
	free(iter);
	pthread_mutex_unlock(&(prev->node_lock));
	pthread_mutex_unlock(&(post->node_lock));
	return;
}
//********************************************************************
void print_list(list* list)
{
    if (list == NULL); 
    else
    {
        node* pointer = list->list_head;
        while (pointer != NULL) {
            printf("%d ", (pointer->value));
            pointer = pointer->next_p;
        }

    }

    printf("\n"); // DO NOT DELETE
}

//********************************//
// given a specific feature , counts how many elements in the node satisfy this feature
void count_list(list* list, int (*predicate)(int))
{
  int count = 0;
  if(list == NULL || list->list_head == NULL) // if list pointer is NULL then print that count = 0 and finish this means that the list was not created or the list is empty in both cases we print zero
  {
    printf("%d items were counted\n", count);
    return;
  }
  
  node* curr = list->list_head; //new pointer curr as in current 
  pthread_mutex_lock(&(curr->node_lock));// lock the first element in the list the head

  if(predicate(curr->value))//check whether the head satisfys the given feature
	  count++;

  node* temp = curr->next_p;

  if(temp == NULL) //if so this means that the list has only one element so  we are done counting
  {
     pthread_mutex_unlock(&(curr->node_lock));
     printf("%d items were counted\n", count);
     return;
  }

  pthread_mutex_lock(&(temp->node_lock)); // there is more than one element in the list , lock the next element 

  while (1)
  {
     pthread_mutex_unlock(&(curr->node_lock)); // unlock current node
     curr = temp; // curr is now a pointer to the next node
     if(predicate(curr->value)) // if current node satifies the given feature 
		 count++; 
     temp = temp->next_p; // // temp becomes the next node
     if(temp == NULL) break; // exit loop if we reach the end of the list
	 else 
		 pthread_mutex_lock(&(temp->node_lock)); // lock temp
  }

  pthread_mutex_unlock(&(curr->node_lock)); // unlock the last element in the list for others to use
  printf("%d items were counted\n", count); // print count
}
