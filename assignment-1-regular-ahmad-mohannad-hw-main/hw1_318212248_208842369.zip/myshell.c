#include <sys/types.h>
#include <sys/wait.h>
#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include <stdlib.h>

#define BUFFER_SIZE 100 //max size of (the number of letters in a command
#define MAX_COMMAND_NUMBER 100 //maximum number of commands we need to restore in case we need to print with history
#define MAX_ARG_NUM 100 // number of arguments in a command


void print_history(char *commands[] , int c_num);
void clear_arr(char* arr[], int size); 

int main(void)
{
    close(2);
    dup(1);
    char command[BUFFER_SIZE];                //an array to storer the typed command
	char command_copy[BUFFER_SIZE];			  //a copy of the command
    char *commands_array[MAX_COMMAND_NUMBER]; //an array to store commands mainly to typing them 
	int command_num = 0;                      //counter of legal commands 
	int hazet_flag = 0;                       //a flag when given a command that will run infront
	const char his[] = "history";             
	int command_len = 0;                      //counter of commands length
	
    while (1)
    {
        fprintf(stdout, "my-shell> ");
        memset(command, 0, BUFFER_SIZE);
        fgets(command, BUFFER_SIZE, stdin);
        if(strncmp(command, "exit", 4) == 0)
        {
            break;
        }
		
		hazet_flag = 0;
		char *argv[MAX_ARG_NUM];
		command_len = strlen(command);
		if(command[command_len-1] == '\n') // we change the last letter of the command to \0 so it would be easy to manipulete the string
			command[command_len-1] = '\0';
		strcpy(command_copy,command); //copy the string in case we dont change in the original command
		
		char *new_string = NULL; // we create a new string and to save the command an an array
		new_string = (char*)malloc((command_len)*sizeof(char)); /*+1 for '\0' character */
		strcpy(new_string,command_copy);
		char *tkn = strtok(command," ");
		
			commands_array[command_num] = new_string; // inserrt the new command to the array of commands
			command_num = command_num + 1;
		
		if(strcmp(tkn,his) == 0){// in case the user typed history command we dont print it and we print all the typed commands MAX 100
			command_num--;
			print_history(commands_array,command_num);
			continue;
		}
		
		int i = 0; // split the command into seperate words for the execvp function to use
		while( tkn != NULL ) {
			if(i < MAX_ARG_NUM){
				argv[i] = tkn;
			}
			i++;
			tkn = strtok(NULL," ");
		}

		if(strcmp(argv[i-1],"&") == 0){//check whether we want to play the command in the front(hazet)
			argv[i] = "&";
			argv[i-1] = NULL;
			hazet_flag = 1;
		}
		else argv[i] = NULL;
		
		
		pid_t pid = fork(); //fork (split processes)
		int exec_ret_value; //return value of the execvp function
		
		if(pid < 0){ // in case the fork did not work
			fprintf(stdout,"Error occured!");
			exit(1);
		}
		else if(pid == 0){ // in case we are in the child process
			exec_ret_value = execvp(argv[0],argv);
			if (exec_ret_value <= -1){ // if the user typed an illgal command or the command fauled to execute
				command_num--;
				fprintf(stdout,"Error occured!\n");
			}
			exit(0);		
		}
		else {
			if(hazet_flag == 0){//in case we need to execute the process infront line
				waitpid(pid,NULL,0);
			}
		}    
    }
	clear_arr(commands_array,command_num); // a function to free all the allocated memory
    return 0;
}


void print_history(char *commands[] , int c_num){//a function to print the history
	int c = 0;
	for(c = 0 ;c < c_num ; c++){
		printf("%s\n",commands[c]);
	}
	return;
}

void clear_arr(char* arr[], int size)//a function to free all cells allocated in the commands array
{
    for (int i = 0; i < size; i++)
    {
        free(arr[i]);
        arr[i] = NULL;
    }

}
